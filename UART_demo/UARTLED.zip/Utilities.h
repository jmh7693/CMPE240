char backspace(char buffer[], int count);
char clearBuffer(char buffer[], int len);
